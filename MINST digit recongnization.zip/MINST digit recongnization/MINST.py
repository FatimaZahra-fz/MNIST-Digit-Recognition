# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Load dataset
print("Loading dataset...")

df = pd.read_csv("train.csv")

print("Dataset Loaded Successfully")

# Features and labels
X = df.drop('label', axis=1)
y = df['label']

# Normalize pixel values
X = X / 255.0

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Build model
model = Sequential()

# Input + Hidden Layer
model.add(Dense(128, activation='relu', input_shape=(784,)))

# Hidden Layer
model.add(Dense(64, activation='relu'))

# Output Layer
model.add(Dense(10, activation='softmax'))

# Compile model
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# Train model
print("Training Model...")

history = model.fit(
    X_train,
    y_train,
    epochs=10,
    batch_size=32,
    validation_split=0.2
)

# Evaluate model
loss, accuracy = model.evaluate(X_test, y_test)

print("\nTest Accuracy:")
print(accuracy)

# ===============================
# SELECT A REAL DIGIT 6 FROM TEST DATA
# ===============================

# Find first image whose label is 6
index_of_6 = y_test[y_test == 6].index[0]

# Get image data
sample = X.loc[index_of_6].values.reshape(1, 784)

# Predict
prediction = model.predict(sample)

predicted_digit = np.argmax(prediction)

print("\nPredicted Digit:")
print(predicted_digit)

# Show image
image = sample.reshape(28, 28)

plt.imshow(image, cmap='gray')
plt.title(f"Predicted Digit: {predicted_digit}")
plt.axis('off')

plt.show()